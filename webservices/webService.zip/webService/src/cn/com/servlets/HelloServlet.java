package cn.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import cn.com.service.servlet.exception.ServletException;
import cn.com.service.servlet.http.HttpServlet;
import cn.com.service.servlet.http.HttpServletRequest;
import cn.com.service.servlet.http.HttpServletResponse;

/**
 * title:�û�������
 * 
 * @author Administrator
 * 
 */
public class HelloServlet extends HttpServlet {

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("����init��");
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = res.getWrite();
		out.println("<html>");
		out.println("<head>");
		out.print("<title>Hello</title>");
		out.println("</head>");
		out.println("<body bgcolor=red><h1 align='center'>Hello Servlet  Get<h1></body>");
		out.println("</html>");

	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("��Ҫ�������ˣ�");
	}

}
