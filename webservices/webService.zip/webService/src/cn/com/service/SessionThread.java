package cn.com.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Map;

import cn.com.service.servlet.exception.ServletException;
import cn.com.service.servlet.http.HttpServlet;
import cn.com.service.servlet.http.HttpServletRequest;
import cn.com.service.servlet.http.HttpServletRequestImp;
import cn.com.service.servlet.http.HttpServletResponse;
import cn.com.service.servlet.http.HttpServletResponseImp;

/**
 * title:ҵ�����߳�
 * @author Administrator
 *
 */
public class SessionThread extends Thread {
	private Socket s;
	private BufferedReader br;
	private PrintWriter out;
    private Map<String,String>config;
	public SessionThread(Socket s,Map<String,String>config) {
		this.s = s;
		this.config=config;
		try {
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			out = new PrintWriter(s.getOutputStream(), true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void run() {
		BufferedReader brFile = null;
		HttpServletRequest req=null;
		HttpServletResponse res=null;
		
		try {
			req=new HttpServletRequestImp(br);
			
			String head = req.getHead();
			String method=req.getMethod();
			String url  =req.getRequestURL();  
			String  pro=req.getProtocol();
			String  filePath = "";
			String[] temp = head.split(" ");
			if (temp.length != 3) {
				return;
			}
			if (!(method.equalsIgnoreCase("get") || method
					.equalsIgnoreCase("post"))) {
				return;
			}
			filePath=url;
			if (url.equals("/")) {
				filePath = "/index.html";
			}
			if (!(pro.equalsIgnoreCase("http/1.1") || pro
					.equalsIgnoreCase("http/1.0"))) {
				return;
			}
		
			
			File f = new File(filePath);
			// ����htmls
			if (f.getName().toLowerCase().endsWith(".html")
					|| f.getName().toLowerCase().endsWith(".htm")) {
				filePath = "webapps" + filePath;
				f=new File(filePath);
				if (f.exists()) {
					res = new HttpServletResponseImp(out, "200");
					brFile = new BufferedReader(new FileReader(f));
					String data = null;
					while ((data = brFile.readLine()) != null) {
						out.println(data);
					}
				} else {
					res = new HttpServletResponseImp(out, "404");
					
				}

			} else if (f.getName().toLowerCase().endsWith(".jsp")) {
             //����servlet
			} else {
                if(config.containsKey(url)){
                String classpath=config.get(url);
                Class c=null;
                HttpServlet hs=null;
                res = new HttpServletResponseImp(out, "200");
                try {
					c=Class.forName(classpath);
					 hs=(HttpServlet)c.newInstance();
					 hs.init();
					 hs.service(req, res);
					 hs.destroy();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                	
                }else{
                	
                	res = new HttpServletResponseImp(out, "404");
						
                }
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res = new HttpServletResponseImp(out, "500");
		} finally {
			if (brFile != null) {
				try {
					brFile.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (out != null) {
				out.close();
			}
			if (s != null) {
				try {
					s.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}
}
