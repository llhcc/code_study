package cn.com.service;
/**
 * title:�������
 * @author Administrator
 *
 */
public class Start {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new WebService();
	}

}
