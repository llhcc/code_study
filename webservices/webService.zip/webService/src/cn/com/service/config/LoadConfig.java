package cn.com.service.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

/**
 * title:xml�����ļ���ȡ
 * 
 * @author Administrator
 * 
 */
public class LoadConfig {

	private LoadConfig() {

	}

	public static Map<String, String> getConfig() {
		Map<String, String> map = new HashMap<String, String>();
		SAXBuilder build = new SAXBuilder();
		try {
			Document doc = build.build(new FileInputStream(new File("WEB-INF/web.xml")));
			Element root = doc.getRootElement();
			List<Element> servers = root.getChildren("servlet",root.getNamespace());
			List<Element> serverMappings = root.getChildren("servlet-mapping",root.getNamespace());
			for (Element sme : serverMappings) {
				String sn = sme.getChildText("servlet-name");
				String up = sme.getChildText("url-pattern");
				for (Element se : servers) {
					String ssn = se.getChildText("servlet-name");
					String ssc = se.getChildText("servlet-class");
					if (ssn.equals(sn)) {
						map.put(up, ssc);
					}
				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JDOMException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return map;
	}

	public static void main(String[] args) {
		Map<String, String> map = LoadConfig.getConfig();
		Set<String> keys = map.keySet();
		for (String s : keys) {
			System.out.println(s + ":" + map.get(s));
		}
	}
}
