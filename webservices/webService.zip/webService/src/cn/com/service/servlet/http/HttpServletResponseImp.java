package cn.com.service.servlet.http;

import java.io.PrintWriter;

public class HttpServletResponseImp implements HttpServletResponse {
	private PrintWriter out;

	public HttpServletResponseImp(PrintWriter out, String status) {
		this.out = out;

		out.println("HTTP/1.1 " + status
				+ " OK\r\nContent-type: text/html; charset=gbk\r\n\r\n");
	}

	@Override
	public PrintWriter getWrite() {
		// TODO Auto-generated method stub
		return this.out;
	}

}
