package cn.com.service.servlet.http;

import java.io.IOException;

import cn.com.service.servlet.exception.ServletException;

/**
 * title:�û��̳���
 * 
 * @author Administrator
 * 
 */
public abstract class HttpServlet {
	// ҵ���߼����ĵ��ȷ���
	public void service(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		String method = req.getMethod();

		if (method.equalsIgnoreCase("get")) {
			doGet(req, res);
		} else if (method.equalsIgnoreCase("post")) {

			doPost(req, res);
		}
	}

	public void init() {

	}

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

	}

	public void destroy() {

	}
}
