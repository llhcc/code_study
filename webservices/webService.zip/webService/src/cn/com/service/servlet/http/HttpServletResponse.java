package cn.com.service.servlet.http;

import java.io.PrintWriter;

/**
 * title����Ӧ���Ľӿ�
 * @author Administrator
 *
 */
public interface HttpServletResponse {
	
     public  PrintWriter getWrite();
}
