package cn.com.service.servlet.exception;

public class ServletException extends Exception {

}
