package cn.com.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;

import cn.com.service.config.LoadConfig;
/**
 * title:web������
 * @author Administrator
 *
 */
public class WebService {
	private ServerSocket ss;
	private static Map<String, String> map;
	static {
		map = LoadConfig.getConfig();

	}

	public WebService() {
		try {
			ss = new ServerSocket(9001);
			System.out.println("�������Ѿ����������ڼ���9001�˿�");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		while (true) {
			try {
				new SessionThread(ss.accept(), map).start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
